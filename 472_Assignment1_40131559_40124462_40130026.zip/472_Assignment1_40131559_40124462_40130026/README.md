# COMP 472 - Mini-project 1

Link to private [GitHub repository](https://github.com/mimi-ta/comp-472-mp1). Please ask for access to view.

## Team

- Vincent Bruzzese 40130026
- Philippe Lee 40131559
- Mimi Ta 40124462

## How to run

The program was separated in terms of questions.

### Running all questions at once

Run ```python init.py``` in command line.

### Running Q1, Q2, or Q3 individually

Run ```python qX.py```

E.g. ```python q2.py```
