print("Running Q1 ...")
import q1
print("")

print("Running Q2 ...")
import q2
print("")

print("Running Q3 ...")
import q3
print("")